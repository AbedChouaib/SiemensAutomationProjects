﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiemensHMI.PlcService
{
    public enum ConnectionStates
    {
        Offline,
        Connecting,
        Online
    }
}
