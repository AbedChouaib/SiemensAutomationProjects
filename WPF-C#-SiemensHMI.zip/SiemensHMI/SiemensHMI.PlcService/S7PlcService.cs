﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using SiemensHMI.PlcService;
using S7.Net;

namespace SiemensHMI
{
    public class S7PlcService
    {
        private readonly System.Timers.Timer _timer;
        private DateTime _lastScanTime;
        private volatile object _lock = new object();
        //public string IPaddress;

        public S7PlcService()
        {
            _timer = new System.Timers.Timer() { Interval = 100 };
            _timer.Elapsed += OnTimerElapsed;
        }
        public ConnectionStates ConnectionState { get; private set; }
        public bool MidLight { get; private set; }
        public bool EdgeLight { get; private set; }
        public bool Live { get; private set; }
        public bool IPavilable { get; private set; }
        private bool delayDisconnectButt = false;
        public TimeSpan ScanTime { get; private set; }
        public EventHandler ValuesRefreshed;
        Plc plc;
        public void Connect(String IPaddress, int rack, int slot)
        {
            if (!Live)
            {
                try
                {
                    plc = new Plc(CpuType.S71200, IPaddress, 0, 1);
                    ConnectionState = ConnectionStates.Connecting;
                    Live = true;
                    plc.Open();
                    Thread.Sleep(30);
                    delayDisconnectButt = true;
                    ConnectionState = ConnectionStates.Online;
                    _timer.Start();
                    IPavilable = false;
                    OnValuesRefreshed();
                }
                catch(PlcException)
                {
                    ConnectionState = ConnectionStates.Offline;
                    Console.WriteLine(DateTime.Now.ToString("HH:mm:ss") + "\t Connection error" + S7.Net.ErrorCode.IPAddressNotAvailable);
                    IPavilable = true;
                    OnValuesRefreshed();
                    throw new Exception("Invalid IP");
                }
                OnValuesRefreshed();
            }
            else
            {
                //OnValuesRefreshed();
                return;
            }
        }
        public void Disconnect()
        {
            if (delayDisconnectButt)
            {
                _timer.Stop();
                plc.Close(); //S7.net method
                ConnectionState = ConnectionStates.Offline;
                Live = false;
                MidLight = false;
                EdgeLight = false;
                OnValuesRefreshed();
            }
        }
        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                _timer.Stop();
                ScanTime = DateTime.Now - _lastScanTime;
                RefreshValues();
                OnValuesRefreshed();
            }
            finally
            {
                _timer.Start();
            }
            _lastScanTime = DateTime.Now;
        }
        private void RefreshValues()
        {
            lock (_lock)
            {
                ReadOut();
            }
        }
        private void OnValuesRefreshed()
        {
            ValuesRefreshed?.Invoke(this, new EventArgs());
        }
        private void ReadOut()
        {
            if (Live)
            {
                var bytes = plc.ReadBytes(DataType.Output, 0, 0, 1);
                System.Collections.BitArray bits = new System.Collections.BitArray(bytes);
                if (bits[0] == true)
                {
                    MidLight = true;
                }
                else if (bits[0] == false)
                {
                    MidLight = false;
                }
                //--------- Second Lamp -------------
                if (bits[1] == true)
                {
                    EdgeLight = true;
                }
                else if (bits[1] == false)
                {
                    EdgeLight = false;
                }
            }
            else
            {
                MidLight = false;
                EdgeLight = false;
            }
        }
        public void MidLampOnOff()
        {
            if (Live)
            {
                lock (_lock)
                {
                    plc.WriteBit(DataType.Memory, 0, 0, 1, true);
                    Thread.Sleep(30);
                    plc.WriteBit(DataType.Memory, 0, 0, 1, false);
                }
            }
            else
            {
                return;
            }
        }
        public void EdgeLampOnOff()
        {
            if (Live)
            {
                lock (_lock)
                {
                    plc.WriteBit(DataType.Memory, 0, 0, 2, true);

                    Thread.Sleep(30);
                    plc.WriteBit(DataType.Memory, 0, 0, 2, false);
                }
            }
            else
            {
                return;
            }
        }
    }
}
