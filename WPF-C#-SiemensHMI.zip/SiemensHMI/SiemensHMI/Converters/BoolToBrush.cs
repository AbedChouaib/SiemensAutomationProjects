﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace SiemensHMI.Converters
{
    class BoolToBrush : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool? state = value as bool?;
            LinearGradientBrush LGB = new LinearGradientBrush(Colors.White, Colors.LightGray, 90);
            LinearGradientBrush LGBG = new LinearGradientBrush(Color.FromRgb(0xdd, 0xff, 0xdd), Color.FromRgb(0x00,0xff,0x00), 90);
            if (state == null)
            {
                return LGB;
            }
            else if (state == true)
            {
                return LGBG;
            }
            else
            {
                return LGB;
            }
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
