﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SiemensHMI.ViewModel;

namespace SiemensHMI.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string IPaddress;
        public MainWindow()
        {
            InitializeComponent();
        }

        //======================================== Methods ==============================================

        private void ToMasterRoom(object sender, RoutedEventArgs e)
        {
            HMItabs.SelectedIndex = 1;
        }

        private void QuitWin(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void ToRoot(object sender, RoutedEventArgs e)
        {
            HMItabs.SelectedIndex = 0;
        }

        private void ConnectToPLC(object sender, RoutedEventArgs e)
        {
            if(IPTextBox.Text.Length == 0)
            {
                WarningMessage.Content = "please enter an IP address!";
            }
            else if(IPTextBox.Text.Length < 8 && IPTextBox.Text.Length > 0)
            {
                WarningMessage.Content = "please enter a valid IP address!";
            }
            else
            {
                return;
            }
        }

        //private void TurnONOFFMid(object sender, RoutedEventArgs e)
        //{
        //    if (!Connected)
        //    {
        //        if (!MidLamp)
        //        {
        //            MidButt.Background = new SolidColorBrush(Color.FromArgb(0xff, 0, 0xff, 0));
        //            MidButt.Content = "Turn OFF";
        //            MidLamp = true;
        //        }
        //        else
        //        {
        //            MidButt.Background = new SolidColorBrush(Colors.LightGray);
        //            MidButt.Content = "Turn ON";
        //            MidLamp = false;
        //        }
        //    }
        //    else
        //    {
        //        return;
        //    }
        //}

        //private void TurnONOFFEdge(object sender, RoutedEventArgs e)
        //{
        //    if (!Connected)
        //    {
        //        if (!EdgeLamp)
        //        {
        //            EdgeButt.Background = new SolidColorBrush(Color.FromArgb(0xff, 0, 0xff, 0));
        //            EdgeButt.Content = "Turn OFF";
        //            EdgeLamp = true;
        //        }
        //        else
        //        {
        //            EdgeButt.Background = new SolidColorBrush(Colors.LightGray);
        //            EdgeButt.Content = "Turn ON";
        //            EdgeLamp = false;
        //        }
        //    }
        //    else
        //    {
        //        return;
        //    }
        //}

        private void ToGirlsRoom(object sender, RoutedEventArgs e)
        {
            HMItabs.SelectedIndex = 2;
        }
        private void ToBoysRoom(object sender, RoutedEventArgs e)
        {
            HMItabs.SelectedIndex = 3;
        }
        //======================================== Methods ==============================================
    }
}
