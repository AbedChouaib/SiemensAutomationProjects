﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;
using System.Windows.Input;
using SiemensHMI.PlcService;
using GalaSoft.MvvmLight.Command;

namespace SiemensHMI.ViewModel
{
    class MainWindowViewModel : ViewModelBase
    {
        private string _IPaddress;
        private short _Rack =0, _Slot=1;
        public string IPTextBox
        {
            get { return _IPaddress; }
            set { Set(ref _IPaddress, value); }
        }
        public short Rack
        {
            get { return _Rack; }
            set { Set(ref _Rack, value); }
        }
        public short Slot
        {
            get { return _Slot; }
            set { Set(ref _Slot, value); }
        }
        public ConnectionStates ConnectionState
        {
            get { return _connectionState; }
            set { Set(ref _connectionState, value); }
        }
        private ConnectionStates _connectionState;
        public TimeSpan ScanTime
        {
            get { return _scanTime; }
            set { Set(ref _scanTime, value); }
        }
        public bool LiveOrNot
        {
            get { return _LiveOrNot; }
            set { Set(ref _LiveOrNot, value); }
        }
        private bool _LiveOrNot;
        public bool MidLamp
        {
            get { return _MidOnOff; }
            set { Set(ref _MidOnOff, value); }
        }
        private bool _MidOnOff;
        public bool EdgeLamp
        {
            get { return _EdgeOnOff; }
            set { Set(ref _EdgeOnOff, value); }
        }
        public int IPAvailability
        {
            get { return _IPAvailability; }
            set { Set(ref _IPAvailability, value); }
        }
        private int _IPAvailability;
        private bool _EdgeOnOff;
        private TimeSpan _scanTime;
        public ICommand ConnectCommand { get; private set; }
        public ICommand DisconnectCommand { get; private set; }
        public ICommand MidLampCommand { get; private set; }
        public ICommand EdgeLampCommand { get; private set; }
        S7PlcService _PlcService;
        public MainWindowViewModel()
        {
            _PlcService = new S7PlcService();
            ConnectCommand = new RelayCommand(Connect);
            DisconnectCommand = new RelayCommand(Disconnect);
            MidLampCommand = new RelayCommand(MidTurnOn);
            EdgeLampCommand = new RelayCommand(EdgeTurnOn);
            OnPlcServiceVlauesRefresh(null, null);
            _PlcService.ValuesRefreshed += OnPlcServiceVlauesRefresh;
        }
        private void OnPlcServiceVlauesRefresh(object sender, EventArgs e)
        {
            ConnectionState = _PlcService.ConnectionState;
            MidLamp = _PlcService.MidLight;
            EdgeLamp = _PlcService.EdgeLight;
            LiveOrNot = _PlcService.Live;
            ScanTime = _PlcService.ScanTime;
            IPAvailability = _PlcService.IPavilable;
        }
        private void Connect()
        {
            //Console.WriteLine("IP address = " + IPTextBox);
            if (_IPaddress == null)
            {
                _IPaddress = "192.168.31.222";
                _PlcService.Connect(_IPaddress, _Rack, _Slot);
            }
            else
            {
                _PlcService.Connect(_IPaddress, _Rack, _Slot);
            }
            
        }
        private void Disconnect()
        {
            _PlcService.Disconnect();
        }
        private void MidTurnOn()
        {
            _PlcService.MidLampOnOff();
        }
        private void EdgeTurnOn()
        {
            _PlcService.EdgeLampOnOff();
        }
        protected void NotAvailable()
        {
            
        }
    }
}
